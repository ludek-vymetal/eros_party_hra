// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get account => '👤 Account';

  @override
  String get addPlayer => 'Add Player';

  @override
  String get addTask => '➕ Add Task';

  @override
  String get agree => 'Agree';

  @override
  String get appTitle => 'EROS';

  @override
  String get author => 'Author';

  @override
  String get boundaries => 'Boundaries';

  @override
  String get boxers => 'Boxers';

  @override
  String get bra => 'Bra';

  @override
  String get cancel => 'Cancel';

  @override
  String get chapter => 'Chapter';

  @override
  String get chapterArchived => '📚 Archived';

  @override
  String get chapterCompleted => '💚 Completed';

  @override
  String get chapterDraft => '✍️ Writing';

  @override
  String get chapterTitle => 'Chapter title';

  @override
  String get chapterWaitingForPartner => '💛 Waiting for partner';

  @override
  String get chooseClothing => 'Choose clothing';

  @override
  String get close => 'Close';

  @override
  String get cloudInbox => '📥 Inbox';

  @override
  String get communityLoadError => 'Failed to load community tasks';

  @override
  String get communityScenarioAlreadyImported => 'Scenario already imported';

  @override
  String get communityScenarioAuthor => 'Author';

  @override
  String get communityScenarioBoundaries => 'Boundaries';

  @override
  String get communityScenarioEmotions => 'Emotions';

  @override
  String get communityScenarioFor => 'For';

  @override
  String get communityScenarioGoal => 'Goal';

  @override
  String get communityScenarioImport => 'Import';

  @override
  String get communityScenarioImported => 'Scenario imported';

  @override
  String get communityScenarioLike => 'Like';

  @override
  String get communityScenarioLoadError => 'Failed to load community scenarios';

  @override
  String get communityScenarioReport => 'Report';

  @override
  String get communityScenarioReportQuestion =>
      'Do you really want to report this scenario?';

  @override
  String get communityScenarios => '🌍 Community Scenarios';

  @override
  String get communityTasks => 'Community Tasks';

  @override
  String get complete => 'Complete';

  @override
  String get completed => '✅ Completed';

  @override
  String get confirmation => 'Confirmation';

  @override
  String get connected => '🔐 Connected';

  @override
  String get continuePartyGame => '▶️ Continue Party Game';

  @override
  String get continueText => 'Continue';

  @override
  String get created => 'Created';

  @override
  String get currentTurn => 'Current Turn';

  @override
  String get czech => '🇨🇿 Czech';

  @override
  String dateLabel(Object date) {
    return '📅 $date';
  }

  @override
  String get difficultyEasy => '1 – Gentle';

  @override
  String get difficultyHard => '3 – No Limits';

  @override
  String get difficultyMedium => '2 – Bold';

  @override
  String get disagree => 'Disagree';

  @override
  String get editScenario => '✏️ Edit Scenario';

  @override
  String get emailAddress => '📧 Email';

  @override
  String get emotionCalm => '😊 Calm';

  @override
  String get emotionCuriosity => 'Curiosity';

  @override
  String get emotionDominance => 'Dominance';

  @override
  String get emotionExcited => '❤️ Excited';

  @override
  String get emotionExcitement => 'Excitement';

  @override
  String get emotionNervous => '😳 Nervous';

  @override
  String get emotionPlayfulness => 'Playfulness';

  @override
  String get emotionRomance => 'Romance';

  @override
  String get emotionSubmission => 'Submission';

  @override
  String get emotionTenderness => 'Tenderness';

  @override
  String get emotionThinking => '💭 Thinking';

  @override
  String get emotionTrust => 'Trust';

  @override
  String get emotionTurnedOn => '🔥 Turned On';

  @override
  String get emotionUnsure => '🤔 Unsure';

  @override
  String get english => '🇺🇸 English';

  @override
  String get enterPartnerCode => 'Enter partner code:';

  @override
  String get enterPlayerName => 'Enter player name';

  @override
  String get exportQr => '📤 Export to QR';

  @override
  String get favorite => 'Favorite';

  @override
  String get favoriteScenarios => '⭐ Favorite Scenarios';

  @override
  String get favoriteScenariosEmpty =>
      'You don\'t have any favorite scenarios yet.';

  @override
  String get female => 'Female';

  @override
  String get fillRequiredFields => 'Fill in all required fields';

  @override
  String get forWho => 'For Who';

  @override
  String get fullyNakedPlayers => '🔥 Completely Naked Players';

  @override
  String get gameDifficulty => 'Game Difficulty';

  @override
  String get generateCode => '🔐 Generate Code';

  @override
  String get givePhoneToPlayer => 'Give the phone to this player:';

  @override
  String get hoodie => 'Hoodie';

  @override
  String get howDoYouDecide => 'What is your decision?';

  @override
  String get howDoYouFeel => 'How do you feel?';

  @override
  String get importScenario => 'Import Scenario';

  @override
  String get importTask => 'Import task';

  @override
  String get inboxCompleted => '✅ Completed';

  @override
  String get inboxPostponed => '⏳ Postponed';

  @override
  String get inboxReceived => '📥 Received';

  @override
  String get inboxRejected => '❌ Rejected';

  @override
  String get incomingReactions => '💬 Received Reactions';

  @override
  String get invalidCode => 'Code is invalid or corrupted';

  @override
  String get language => 'Language';

  @override
  String get lastClothing => '🔥 LAST CLOTHING 🔥';

  @override
  String get latestScenarios => 'Latest Scenarios';

  @override
  String get latestTasks => 'Latest';

  @override
  String get likes => 'Likes';

  @override
  String get link => 'Connect';

  @override
  String get linkedSuccess => '✅ You are connected';

  @override
  String get logout => '🚪 Sign out';

  @override
  String get male => 'Male';

  @override
  String get me => 'Me';

  @override
  String get message => 'Message:';

  @override
  String messageLabel(Object message) {
    return '💬 $message';
  }

  @override
  String get naked => 'naked';

  @override
  String get newPartyGame => '🎉 New Party Game';

  @override
  String get newPartyGamePlayers => 'New Party Game – Players';

  @override
  String get newScenario => '✍️ New Scenario';

  @override
  String get noCloudScenarios => 'No scenarios from your partner yet';

  @override
  String get noCommunityScenarios => 'No community scenarios yet';

  @override
  String get noCommunityTasks => 'No community tasks have been shared yet';

  @override
  String get noEventsYet => 'No events yet';

  @override
  String get noIncomingReactions => 'You don\'t have any reactions yet';

  @override
  String get noScenariosYet => 'No scenarios yet';

  @override
  String get noTasksYet => 'There are no tasks yet';

  @override
  String get notCompleted => '❌ Not completed';

  @override
  String get notConnected => '🔐 Not Connected';

  @override
  String get nothingToHide => 'has nothing left to hide';

  @override
  String get ok => 'OK';

  @override
  String get openScenario => 'Open Scenario';

  @override
  String get ourThoughts => 'Our thoughts';

  @override
  String get panties => 'Panties';

  @override
  String get pants => 'Pants';

  @override
  String get partner => 'Partner';

  @override
  String get partnerLink => 'Partner Connection';

  @override
  String get partnerMode => '❤️ Partner Mode';

  @override
  String get partnerModeTitle => '❤️ PARTNER MODE ❤️';

  @override
  String get partyConsentScreenText =>
      'This party game is intimate, voluntary and may contain erotic elements, undressing and physical closeness.\n\nEvery player has the right to say NO at any time.\nRespect is more important than the game itself.\n\nContinue only if all participants agree.';

  @override
  String get partyConsentText =>
      'this party game is intimate, voluntary and may contain erotic elements, undressing and physical closeness.\n\nYou can say NO at any time.\nDo you agree to participate?';

  @override
  String get partyConsentTitle => 'Game Consent';

  @override
  String get partyGame => 'Party Game';

  @override
  String get pasteFromClipboard => '📋 Paste From Clipboard';

  @override
  String get pasteScenarioCode => 'Paste Scenario Code';

  @override
  String get playerName => 'Player Name';

  @override
  String get playerNotParticipating => 'is not participating';

  @override
  String get postponedStatus => '⏳ Postponed';

  @override
  String get proofAccepted => '✅ Proof Accepted';

  @override
  String get proofAcceptedButton => 'Proof Accepted';

  @override
  String get proofAcceptedSnackBar => 'Proof accepted';

  @override
  String get proofConfirmed => '✅ Proof confirmed';

  @override
  String get proofConfirmedByPartner => '✅ Partner confirmed the proof';

  @override
  String get proofMarkedSent => '📷 Proof marked as sent';

  @override
  String get proofSent => '📷 Proof sent';

  @override
  String get proofSentButton => '📷 I Sent Proof via WhatsApp';

  @override
  String get proofSentQuestion =>
      'Did you really send proof to your partner via WhatsApp?';

  @override
  String get proofSentWhatsapp => '📷 Proof Sent via WhatsApp';

  @override
  String get proofWaiting => '⏳ Waiting for Proof';

  @override
  String get reactToScenario => '💬 React';

  @override
  String get reactionComplete => '✅ I will do it';

  @override
  String get reactionCompleted => 'Completed';

  @override
  String get reactionDateLabel => 'Date:';

  @override
  String get reactionDecision => 'Decision';

  @override
  String get reactionDetail => 'Reaction Detail';

  @override
  String get reactionMessage => 'Write a reaction';

  @override
  String get reactionMessageLabel => 'Message:';

  @override
  String get reactionMessageRequired => '✍️ Please write a reason or reaction.';

  @override
  String get reactionNotCompleted => 'Not Completed';

  @override
  String get reactionPostpone => '⏳ Postpone';

  @override
  String get reactionReject => '❌ I refuse';

  @override
  String get reactionSent => 'Reaction sent';

  @override
  String get reactions => 'reactions';

  @override
  String get readScenario => '📖 Read Scenario';

  @override
  String get receivedStatus => '📥 Received';

  @override
  String get reconsiderScenario => '❤️ Reconsider';

  @override
  String get refuse => 'Refuse';

  @override
  String get rejectedScenarioInfo =>
      '❌ This scenario was rejected.\n\nWould you like to reconsider it?';

  @override
  String get rejectedStatus => '❌ Rejected';

  @override
  String get relationshipAboutChapter => 'About this chapter';

  @override
  String get relationshipBook => 'Relationship Book';

  @override
  String get relationshipChallenge => 'The challenge that started it all';

  @override
  String get relationshipJournal => '❤️ Relationship Journal';

  @override
  String get relationshipJournalEmpty =>
      'You don\'t have any shared memories yet.';

  @override
  String get relationshipNoPhotos => 'There are no photos yet.';

  @override
  String get relationshipPhotos => 'Our Photos';

  @override
  String get relationshipReflectionPlaceholderMine =>
      'Your reflection will appear here.';

  @override
  String get relationshipReflectionPlaceholderPartner =>
      'Your partner\'s reflection will appear here.';

  @override
  String get relationshipReflections => 'Our reflections';

  @override
  String get relationshipStory => 'Our Story';

  @override
  String get relationshipStorySubtitle =>
      'Every shared memory becomes another page of your story.';

  @override
  String get reportScenario => 'Report Scenario';

  @override
  String get reportScenarioQuestion =>
      'Do you really want to report this scenario?';

  @override
  String get reportTask => 'Report';

  @override
  String get reportTaskQuestion => 'Do you want to report this task?';

  @override
  String get rescueApproved => 'Rescue approved!';

  @override
  String get rescueDenied => 'Rescue denied!';

  @override
  String get rescueDeniedText =>
      'Don\'t worry! There will be another vote in 5 rounds. Try to convince others next round!';

  @override
  String get rescueQuestion => 'Do you want to rescue the naked player?';

  @override
  String get rescueSelectFirst => 'Rescue: Select 1st clothing';

  @override
  String get rescueTitle => '🛟 RESCUE';

  @override
  String get rescuedPlayer => 'Rescued player:';

  @override
  String get saveAndExit => 'Save and Exit';

  @override
  String get saveChanges => '💾 Save Changes';

  @override
  String get saveToRelationshipJournal => 'Save to relationship journal';

  @override
  String get saveToRelationshipJournalQuestion =>
      'Would you like to save this moment to your relationship journal?';

  @override
  String get scenarioAlreadyImported => 'Scenario already imported';

  @override
  String get scenarioDetail => 'Scenario Detail';

  @override
  String get scenarioEmotions => 'What emotions should the scenario evoke?';

  @override
  String get scenarioGoal => '🎯 Scenario Goal';

  @override
  String get scenarioHistory => '🕰️ Scenario History';

  @override
  String get scenarioImported => 'Scenario imported';

  @override
  String scenarioLabel(Object name) {
    return '🏷️ $name';
  }

  @override
  String get scenarioMovedToPostponed => '⏳ Scenario moved to postponed';

  @override
  String get scenarioReported => 'Scenario reported';

  @override
  String get scenarioText => 'Scenario Text';

  @override
  String get scenarioTitle => 'Scenario Title';

  @override
  String get selectClothing => 'Click clothing you want to wear:';

  @override
  String get send => 'Send';

  @override
  String get sendReaction => '💌 Send Reaction';

  @override
  String get sendReactionTitle => 'Send Reaction';

  @override
  String get sentAt => 'Sent';

  @override
  String get settings => '⚙️ Settings';

  @override
  String get shareAnonymously => 'Share anonymously';

  @override
  String get shareToCommunity => 'Share with community';

  @override
  String get shoes => 'Shoes';

  @override
  String get skip => 'Skip';

  @override
  String get socks => 'Socks';

  @override
  String get startGame => 'Start Game';

  @override
  String get stateMaybeLater => 'maybe later';

  @override
  String get stateWillDo => 'I will do it';

  @override
  String get stateWillNotDo => 'I will not do it';

  @override
  String get status => 'Status';

  @override
  String get sweater => 'Sweater';

  @override
  String get taskAlreadyImported => 'This task is already imported';

  @override
  String get taskImported => 'Task imported';

  @override
  String get taskManager => '🛠 Task Manager';

  @override
  String get taskManagerTitle => '🛠️ Task Manager';

  @override
  String get taskReported => 'Task reported';

  @override
  String get taskShareFailed => 'Failed to share task';

  @override
  String get taskShared => 'Task shared with community';

  @override
  String get timeline => 'Timeline';

  @override
  String get topScenarios => 'Top Rated Scenarios';

  @override
  String get topTasks => 'Top Rated';

  @override
  String get tshirt => 'T-Shirt';

  @override
  String get unlink => 'Disconnect';

  @override
  String get votingPlayer => 'Voting player:';

  @override
  String get waitingProof => '⏳ Waiting for proof';

  @override
  String get waitingProofConfirmation => '📷 Waiting for proof confirmation';

  @override
  String get waitingProofUpload => '⏳ Waiting to send proof';

  @override
  String get write => 'Write';

  @override
  String get writeScenario => '✍️ Write New Scenario';

  @override
  String get yes => 'YES';

  @override
  String get youRemove => 'You remove:';

  @override
  String get yourCode => 'Your code:';

  @override
  String get no => 'NO';

  @override
  String get sharedMemory => '❤️ Shared Memory';

  @override
  String get statistics => '📊 Statistics';

  @override
  String get attachProof => '📷 Attach Proof';

  @override
  String get copyCode => '📋 Copy Code';
}
