import 'package:flutter/material.dart';

class BookPager extends StatefulWidget {
  final List<Widget> spreads;

  const BookPager({
    super.key,
    required this.spreads,
  });

  @override
  State<BookPager> createState() => _BookPagerState();
}

class _BookPagerState extends State<BookPager> {
  int currentSpread = 0;

  void nextSpread() {
    if (currentSpread >= widget.spreads.length - 1) {
      return;
    }

    setState(() {
      currentSpread++;
    });
  }

  void previousSpread() {
    if (currentSpread <= 0) {
      return;
    }

    setState(() {
      currentSpread--;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [

        AnimatedSwitcher(
          duration: const Duration(milliseconds: 500),

          switchInCurve: Curves.easeOutCubic,
          switchOutCurve: Curves.easeInCubic,

          transitionBuilder: (child, animation) {
            final slide = Tween<Offset>(
              begin: const Offset(0.08, 0),
              end: Offset.zero,
            ).animate(animation);

            final fade = CurvedAnimation(
              parent: animation,
              curve: Curves.easeOut,
            );

            return FadeTransition(
              opacity: fade,
              child: SlideTransition(
                position: slide,
                child: child,
              ),
            );
          },

          child: KeyedSubtree(
            key: ValueKey(currentSpread),
            child: widget.spreads[currentSpread],
          ),
        ),

        Positioned(
          left: 20,
          top: 0,
          bottom: 0,
          child: Center(
            child: IconButton(
              iconSize: 38,
              onPressed: previousSpread,
              icon: const Icon(
                Icons.chevron_left,
              ),
            ),
          ),
        ),

        Positioned(
          right: 20,
          top: 0,
          bottom: 0,
          child: Center(
            child: IconButton(
              iconSize: 38,
              onPressed: nextSpread,
              icon: const Icon(
                Icons.chevron_right,
              ),
            ),
          ),
        ),
      ],
    );
  }
}