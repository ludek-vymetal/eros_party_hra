class MemoryEmotion {

}