import 'package:flutter/material.dart';

class RelationshipBookViewerScreen extends StatefulWidget {
  final List<Widget> spreads;

  const RelationshipBookViewerScreen({
    super.key,
    required this.spreads,
  });

  @override
  State<RelationshipBookViewerScreen> createState() =>
      _RelationshipBookViewerScreenState();
}

class _RelationshipBookViewerScreenState
    extends State<RelationshipBookViewerScreen> {

  int currentSpread = 0;

  void nextSpread() {
    if (currentSpread >= widget.spreads.length - 1) {
      return;
    }

    setState(() {
      currentSpread++;
    });
  }

  void previousSpread() {
    if (currentSpread <= 0) {
      return;
    }

    setState(() {
      currentSpread--;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [

          AnimatedSwitcher(
            duration: const Duration(
              milliseconds: 500,
            ),

            child: KeyedSubtree(
              key: ValueKey(currentSpread),
              child: widget.spreads[currentSpread],
            ),
          ),

          Positioned(
            left: 12,
            top: 0,
            bottom: 0,
            child: Center(
              child: IconButton(
                icon: const Icon(Icons.chevron_left),
                iconSize: 42,
                onPressed: previousSpread,
              ),
            ),
          ),

          Positioned(
            right: 12,
            top: 0,
            bottom: 0,
            child: Center(
              child: IconButton(
                icon: const Icon(Icons.chevron_right),
                iconSize: 42,
                onPressed: nextSpread,
              ),
            ),
          ),
        ],
      ),
    );
  }
}